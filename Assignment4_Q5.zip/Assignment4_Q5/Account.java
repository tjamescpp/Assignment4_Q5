package Assignment4_Q5;


public class Account {
    private AccountHolder holder;
    private double balance = 0.0;

    Account(double amt, AccountHolder holder){
        balance = amt;
        this.holder = holder;
    }

    public void deposit(double amt){
        balance = balance + amt;
    }

    public void withdraw(double amt){
        balance = balance - amt;
    }

    public double getBalance(){
        return balance;
    }

    public AccountHolder getHolder() {
        return holder;
    }

    public void setBalance(double amt) {
        balance = amt;
    }

    public void setHolder(AccountHolder holder) {
        this.holder = holder;
    }
}