package Assignment4_Q5;

import java.util.Random;

abstract class AccountHolder {
    protected int ID;
    protected String address;

    AccountHolder(int ID, String address){
        this.ID = ID;
        this.address = address;
    }

    public int getNextID(){
        int nextID = new Random().nextInt(1000001);
        return nextID;
    }
}
